# -*- coding: utf-8 -*-
'''
Created on 2 ene. 2020

@author: mariano
'''

from contratos import *

################################################################
#  Programa principal
################################################################
if __name__ == '__main__':
    
    print('EJERCICIO 1:')

    
    print('EJERCICIO 2:')


    print('EJERCICIO 3:')

    
    print('EJERCICIO 4:')

    
    print('EJERCICIO 5:')

    
    print('EJERCICIO 6:')

